export class Employee{
    eId:number;
    eName:string;
    eSalary:number;
    eType:string;
    eDepartment:string;
    eskill:string;
    

}